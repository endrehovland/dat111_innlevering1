HVL Læringslabb – Innlevering 1 (Del 2)

Innhold:
- index.html (BRH-1)
- om.html (BRH-2)
- kontakt.html (BRH-5)
- img/ (plassholder-bilder i SVG-format)

Krav i oppgaven er fulgt:
- Minst to overskriftsnivåer på hver side
- Lister (inkl. nøstet liste på forsiden)
- Tabell (kontakt-siden)
- Semantiske elementer: <strong>, <em>, <header>, <main>, <footer>, <nav>, <article>, <section>
- Bilder med relative stier og alt-tekst
- Ingen CSS (kommer i neste innlevering)

Tips:
- Pakk mappen som ZIP og lever i Canvas.
- Test validering: https://validator.w3.org/
